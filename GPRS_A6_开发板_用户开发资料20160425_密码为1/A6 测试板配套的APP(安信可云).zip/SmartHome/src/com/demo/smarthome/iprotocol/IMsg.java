package com.demo.smarthome.iprotocol;

public interface IMsg {

}
