package com.demo.smarthome.iprotocol;

public interface ICrc {

}
