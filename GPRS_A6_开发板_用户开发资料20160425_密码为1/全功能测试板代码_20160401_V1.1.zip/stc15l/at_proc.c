
#include "at_proc.h"



#define  AT_CMD_AT    "AT \r\n"
#define  AT_CMD_CSQ    "AT+CSQ\r\n"

//gprs
#define  AT_CMD_CGATT   "AT+CGATT=1\r\n"
#define  AT_CMD_CGDCONT "AT+CGDCONT=1, \"IP\", \"cmnet\" \r\n"
#define  AT_CMD_CGACT   "AT+CGACT=1,1 \r\n"
#define  AT_CMD_ATDGPRS  "ATD*99***1# \r\n"

#define AT_CMD_CLDSTART   "AT+CLDSTART \r\n"
#define AT_CMD_CLDSTOP    "AT+CLDSTOP \r\n"
#define AT_CMD_CLDUNBIND  "AT_CLDUNBIND \r\n"


#define AT_CMD_COMMON_ERROR  "+CME ERROR:"
  
  							   


 typedef struct
 {
   u8 cmdNo;
   u8 cmd[15];
   u8 success[15];
   u8 failed[15]; 
   u8 result;
 }AT_CMD_PARAM;

#define CMD_TABLE_LENGTH  15
AT_CMD_PARAM xdata cmd_table[]={
{1,"AT","OK","",AT_CMD_UNKNOWN},
{2,"+CREG?","+CREG:","",AT_CMD_UNKNOWN},
{3,"+CSQ","+CSQ:","",AT_CMD_UNKNOWN},
{4,"ATD","OK","NO ANSWER",AT_CMD_UNKNOWN},
{5,"ATH","OK","+CME",AT_CMD_UNKNOWN},
{6,"+CMGF","OK","+CME",AT_CMD_UNKNOWN},
{7,"+CMGS","OK","+CME",AT_CMD_UNKNOWN},
{8,"+CGDCONT","OK","+CME",AT_CMD_UNKNOWN},
{9,"+CGACT","OK","+CME",AT_CMD_UNKNOWN},
{10,"+CLDSTART","+CLDSTART:","",AT_CMD_UNKNOWN},
{11,"+CLDSTOP","+CLDSTOP:","",AT_CMD_UNKNOWN},
{12,"+CLDUNBIND","+CLDUNBIND:","",AT_CMD_UNKNOWN},
{13,"+SNFS","OK","",AT_CMD_UNKNOWN},
{14,"+COPS","+COPS:","",AT_CMD_UNKNOWN},
{15,"","","",AT_CMD_UNKNOWN},
};

#define AT_RX_BUFFER  100
 
 u8 rx_buffer[AT_RX_BUFFER];
 u8 sendAtCmdNo=0;

 u8 networkIsReg=0;

#define AT_TEST_SMS_COMTENT  "This is a test sms , sended by Ai-Thinker A6 Full Test Board.Thank you!"

#define AT_COMMON_ERROR_STRING   "+CME ERROR:"
#define AT_COMMON_ERROR_STRING_LENGTH 	11
/*
 +CIEV: "CALL",1

+CIEV: "SOUNDER",1

+CIEV: "SOUNDER",0
ath

+CIEV: "CALL",0

OK
*/

void send_at_cmd(u8* cmd,u8 atCmdNo)
{   
   sendAtCmdNo=atCmdNo;
   SendString(USART2,cmd);  
  // delay_ms(2000);
}

u8   cld_is_connect()
{
  	return cmd_table[9].result;
}

void send_aicloud_at()
{
   if(cmd_table[9].result == AT_CMD_FAILED)
   {
      SendString(USART2,"AT+CLDSTOP\r\n");
	  delay_ms(5000);
   } 
   //ResetTxBuffer();

   sendAtCmdNo=10;  
   SendString(USART2,"AT+CLDSTART \r\n");
   delay_ms(3000);   
}

void send_dial_at(u8 phone_number[])
{
   u8 buffer[30];

   sendAtCmdNo=13;

   sprintf(buffer,"AT+SNFS=0\r\n"); //Ĭ��ʹ�ö�����绰 
   SendString(USART2,buffer);

   delay_ms(2000);

   if(cmd_table[3].result != AT_CMD_UNKNOWN)
   {
      SendString(USART2,"ATH\r\n");
	  delay_ms(5000);
   }  

   sendAtCmdNo=4;
   sprintf(buffer,"ATD%s\r\n",phone_number); 
   SendString(USART2,buffer);
   
   delay_ms(1000);      
}

void send_sms_at(u8 phone_number[])
{
   u8 buffer[100]="",i;

   sendAtCmdNo=0;
   
   SendString(USART2,"AT+CMGF=1 \r\n");//textģʽ����

   delay_ms(2000);

   //sprintf(buffer,"AT+CMGS=\"%s\"\r\n",phone_number); //textģʽ����   
   strcpy(buffer,"AT+CMGS=\"");
   i=strlen(buffer);
   strcpy(buffer+i,phone_number);
   i=strlen(buffer);
   strcpy(buffer+i,"\"\r\n");

   SendString(USART2,buffer);

   delay_ms(2000);

   sendAtCmdNo=7;
   //sprintf(buffer,"%s \0x1A",AT_TEST_SMS_COMTENT); //textģʽ����,\0x1A CTRL-Z 
   SendString(USART2,AT_TEST_SMS_COMTENT);
   SendData(USART2,0x1a);   
}

void cld_recv(u8* str,u8 length)  //�����ַ���ʽ����6,123456
{
  u8 len=0;
  u16 i=0;
  CTRL_PROTOL*  protol;

  //SendString(USART1,str);

  while(str[i]>='0' && str[i]<='9')
  {
      len=len*10+str[i]-'0';

	  i++;
  }	  

  if(len!=sizeof(CTRL_PROTOL) || (length-(i+1)-2)!=sizeof(CTRL_PROTOL))//���ȼ��
  {
    SendString(USART1,"cld_recv error\r\n");
    return;
  } 
   
  protol=(CTRL_PROTOL*)(str+i+1);

  //SendData(USART1,protol.device);
  //SendData(USART1,protol.config.beep_config.mode);

  if(protol->device=='1')//led ��
  {
	if(protol->config.led_config.mode=='0')  //�ر�LED
	{
	  led_rgb_off();
	}
	else if(protol->config.led_config.mode=='1')  //��LED
	{
	  led_rgb_set(protol->config.led_config.red-'0',protol->config.led_config.green-'0',protol->config.led_config.blue-'0');
	}
	else if(protol->config.led_config.mode=='2')  //Blink LED
	{
	  led_rgb_blink(protol->config.led_config.time-'0',50);
	}	
  }
  else if(protol->device=='2')	//beep
  {
	if(protol->config.beep_config.mode=='0')  //�ر�BEEP
	{
	  beep_off();
	}
	else if(protol->config.beep_config.mode=='1')  //��BEEP
	{
	  beep_on();
	}
	else if(protol->config.beep_config.mode=='2')  //Blink BEEP
	{
	  beep_on_second(protol->config.beep_config.time-'0');
	}	
  }
  else if(protol->device=='3') //�̵���
  {
  	if(protol->config.relay_config.mode=='0')  //�رռ̵���
	{
	  relay_off();
	}
	else if(protol->config.relay_config.mode=='1')  //�򿪼̵���
	{
	  relay_on();
	}
	else if(protol->config.relay_config.mode=='2')  //Blink �̵���
	{
	  relay_on_second(protol->config.relay_config.time-'0');
	}	
  }
  else if(protol->device=='4') //A6 module
  {
	if(protol->config.module_config.mode=='r')  //reset A6
	{
	  a6_module_reset();
	}
  }
  else 
  {
    return;
  }

}

void creg_recv(u8* str,u8 length)  //�����ַ���ʽ����01
{
  u8 len=0,regVal;
  u16 i=0;  
  //SendString(USART1,str);

  regVal=0;
  while(i<(length-2))
  {
  	if(str[i]>='0' && str[i] <='9')
	{
	  regVal=regVal*10+str[i]-'0';
	}
	
	if(str[i] == ',' || str[i]=='\0')
		break;

   	i++;
  }
   
  networkIsReg=regVal;
 // SendData(USART2,networkIsReg+'0');
}

void at_proc(u8* pCdmStr,u8 length)
{
  u8 i=0;
  u8 *pSuccStr;//*pFailStr,len;
  u8 succStrLen;

  //SendDebug("at_proc,%s",pCdmStr);
  //SendString(USART1,"at_proc:");
  //SendString(USART1,pCdmStr); 

   //if(sendAtCmdNo<=0 || sendAtCmdNo>=CMD_TABLE_LENGTH) //�ж��Ƿ���ǰ�淢�͹�at��Ҫ������
	//	  return ; 

  if(!(pCdmStr[length-2]=='\r' && pCdmStr[length-1]=='\n'))
	      return;

  if(length==2) //���У�������
         return ; 
	 
	i=0; 
  while(pCdmStr[i]==' ') i++;  //���˵�ǰ��Ŀո�

  if(cmd_table[9].result == AT_CMD_SUCCESS)
  {
     if(mem_cmp(pCdmStr,"+CLDRCV:",8)==0)
	 { //��ƽ̨�յ�������
	 	//SendString(USART1,"qw\r\n");
	   	cld_recv(pCdmStr+8,length-8);
	   return;
	 }   
  }	  	
	
 if(length>=8&& mem_cmp(pCdmStr,"+CREG:",6)==0)
 { //��ѯ�Ƿ�ע�ᵽ����
 	//SendString(USART1,"qw1\r\n");   
   	creg_recv(pCdmStr+6,length-6);
   	return;
  } 
  /* 
  if(length>=9 && mem_cmp(pCdmStr,"+CGREG:",7)==0)
  { //��ѯ�Ƿ�ע�ᵽ����
 	//SendString(USART1,"qw2\r\n");   
    creg_recv(pCdmStr+7,length-7);
    return;
  }	*/


  pSuccStr=cmd_table[sendAtCmdNo-1].success;

  succStrLen= str_len(pSuccStr);  
  switch(sendAtCmdNo)
  {
    case 1:	//at
		{
		  if(mem_cmp(pSuccStr,pCdmStr,succStrLen)==0)
  			{
			   cmd_table[sendAtCmdNo-1].result=AT_CMD_SUCCESS;
			   SendString(USART1,"AT result=2 \r\n");

			   sendAtCmdNo=0;
  			}	  
			else if(mem_cmp(pCdmStr,AT_COMMON_ERROR_STRING,AT_COMMON_ERROR_STRING_LENGTH)==0)
			{
				 cmd_table[sendAtCmdNo-1].result=AT_CMD_FAILED;					 
				 SendString(USART1,"AT result=1 \r\n");				 
			}
		}
		break;
	case 2:	//+creg
		{
			if(mem_cmp(pSuccStr,pCdmStr,succStrLen)==0)
  			{
			   if(pCdmStr[succStrLen]=='1')
			   {
			   	   cmd_table[sendAtCmdNo-1].result=AT_CMD_SUCCESS;
				   sendAtCmdNo=0;
			   }
			  else
			  {
				   cmd_table[sendAtCmdNo-1].result=AT_CMD_FAILED;
			  }				  
  			}
		}
		break;
	case 3:	 //+csq
		{
		   	if(mem_cmp(pSuccStr,pCdmStr,succStrLen)==0)
  			{
			  if(pCdmStr[succStrLen]!='0')
			  {
			       cmd_table[sendAtCmdNo-1].result=pCdmStr[succStrLen]-'0';				   
				   if(pCdmStr[succStrLen+1]!=',')
				   {
				   		cmd_table[sendAtCmdNo-1].result*=10;
						cmd_table[sendAtCmdNo-1].result+=pCdmStr[succStrLen+1]-'0';				   
				   }			   	   
			  }
			  else
			  {
				   cmd_table[sendAtCmdNo-1].result=AT_CMD_FAILED;
			  }
  			}
		}
		break;
	case 4:	//atd
		{

		}
		break;
	case 5:	//ath
		{ 
		   if(mem_cmp(pSuccStr,pCdmStr,succStrLen)==0)
  			{
			   cmd_table[sendAtCmdNo-1].result=AT_CMD_SUCCESS;
  			}		 
		}
		break;
	case 6:	//+CMGF
		{
		   if(strncmp(pSuccStr,pCdmStr,succStrLen)==0)
  			{
			   cmd_table[sendAtCmdNo-1].result=AT_CMD_SUCCESS;
  			}
		}
		break;
	case 7:	//+CMGS
		{
		}
		break;
	case 8:	//+CGDCONT
		{

		}
		break;
	case 9:	 //+CGACT
		{
		}
		break;
	case 10:	//cldstart
		{
		//	SendString(USART1,"at proc1:");
		 //   SendString(USART1,pCdmStr);
		//	SendString(USART1,pSuccStr);								   		
			if(mem_cmp(pSuccStr,pCdmStr,succStrLen)==0)
  			{
			  if(pCdmStr[succStrLen]=='1')
			  {
			   	   cmd_table[sendAtCmdNo-1].result=AT_CMD_SUCCESS;
				//   SendString(USART1,"AT_CMD_SUCCESS\r\n");
					displayStringWidthScreenPos(4,0,"Aicld start OK");				
					displayStringWidthScreenPos(6,0,"YOU CAN WORK");				

				   sendAtCmdNo=0;
			  }
			  else
			  {
				   cmd_table[sendAtCmdNo-1].result=AT_CMD_FAILED;
			//	   SendString(USART1,"AT_CMD_FAILED\r\n");
			  }				  
  			}
			else
			{
			   cmd_table[sendAtCmdNo-1].result=AT_CMD_FAILED;
			 //  SendString(USART1,"AT_CMD_FAILED2\r\n");
			  
			}
		}
		break;
	case 11:	//cldstop
		{
		}
		break;
	case 12:	//cldunbind
		{
		}
		break;
	case 14: //cops
		{ 		  
		}
		break;
	case 13:
	default:
		break;
  }	      	
}

u8 mem_cmp(u8* src,u8* dst,u8 len)
{
   u8 i=0,ret=0;
  
  while(i<len)
  {
    if(src[i] ==0 || dst[i]==0 ||  src[i]!= dst[i])
	{
	   ret=1;
	   break;
	}  
	
	i++;
  }

  return ret;
}

u8 str_len(u8* string)
{
   u8 i=0;

   while(string[i]!=0) 	i++;

   return i;
}