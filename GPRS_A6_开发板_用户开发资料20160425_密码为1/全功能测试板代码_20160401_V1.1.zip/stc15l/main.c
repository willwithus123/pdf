

#include	"config.h"
#include	"delay.h"
#include	"USART.h"
#include    "ST7567_LCD.h"
#include 	"key_board.h"
#include    "led_rgb.h"
#include    "A6_module.h"
#include    "stdarg.h"



//���ڱ����û�����ĺ��룬�ú�������Ǵ�绰�ĺ��룬Ҳ�����Ƿ����ŵĺ���
#define PHONE_NUMBER_MAX_LENGTH 20		 //�������󳤶�


void gpio_init()
{
   	//P3M1 = 0x00;
	//P3M0 = 0xff;

   	P0M1 =0x00 ;
   	P0M0 =0x00 ;

	P1M1 =0x00 ;
   	P1M0 =0xC0 ;

   	P2M1 =0x00 ;
   	P2M0 =0x00 ; 

	P5M1 = 0x00;
	P5M0 = 0xff;
}

u8  phone_number[PHONE_NUMBER_MAX_LENGTH]; //������������
u8 dialPressNumber=0; 						//�����ж�dial���Ƿ񳤰�	
u8  phone_number_len=0;					  //�����ʵ�ʳ���

				
void main(void)
{	
    u8 key_press=-1;
	u8 i=0;	
	u8  bClearScreen=0;
	u8  bCldStart=0;
	u8 count_s5,count_s10=0;

	gpio_init();

	relay_init();
	beep_init();  

	delay_ms(1000);
	beep_on_ms(3000);
	
	Init_ST7567_LCD();

	clear_screen(0x00);
	displayStringWidthScreenPos(0,0,"sys start...");  			

	led_rgb_blink(3,50);

	USART_Configuration(USART1);		 
	displayStringWidthScreenPos(2,0,"uart1 start OK");	

	//delay_ms(1000);
	USART_Configuration(USART2);
	displayStringWidthScreenPos(4,0,"uart2 start OK");
	//delay_ms(1000);

	//a6_module_init();//ģ���ʼ������
	a6_module_reset();

	delay_ms(1000);
	
	displayStringWidthScreenPos(6,0,"A6  start   OK");	

	key_board_init();

	delay_ms(1000);		
	clear_screen(0x00);	
	displayStringWidthScreenPos(0,0,"kb start   OK");
	
	led_rgb_init();		
	displayStringWidthScreenPos(2,0,"Led start   OK");	
	
	displayStringWidthScreenPos(4,0,"AiCld start.");  
		
	//display_dial_pic(1);	
  
	//��ʼ�����������ڴ�
    for(i=0;i<PHONE_NUMBER_MAX_LENGTH;i++)
	{
	   phone_number[i]=0;  	   
	}
	phone_number_len=0;		

	//SendString(USART1,"scan_kb start \r\n");

	send_at_cmd("AT\r\n",1);
	send_at_cmd("ATE0 \r\n",0);		
	
	if(networkIsReg==1)
	{
	    displayStringWidthScreenPos(4,0,"AiCld start.."); 
		send_aicloud_at();									
		displayStringWidthScreenPos(4,0,"AiCld start...");  
	}
	else
	{ 
		SendString(USART1,"newwork is not register\r\n");
	}

	//displayStringWidthScreenPos(6,0,"");						

	count_s5=0;
	count_s10=0;
	while(1)
	{ 
	  	key_press=scan_kb();
						    
		if(key_press !=  KB_VAL_NULL)
		{
		   if(!bClearScreen)
		   {
		   	   clear_screen(0x00);
			   bClearScreen=1;
		   }

		  if(key_press==KB_VAL_SMS)
		  {			      
			  displayStringWidthScreenPos(6,0,"Send SMS.....");
		      phone_number[phone_number_len]=0;
		      send_sms_at(phone_number);			  
			  displayStringWidthScreenPos(6,0,"              ");			 
		  }								 
		  else if(key_press==KB_VAL_DIAL)
		  {	 
		     dialPressNumber++;
			 if(dialPressNumber >4)
			 {//����dial���൱��ɾ��
		       inputBackspace();

			   if(phone_number_len>0)
			   {
			      phone_number_len--;
			   }
			   phone_number[phone_number_len]=0;
		   	}	    		    
		  }
		  else
		  {		    
		    inputChar(key_press);
			
			phone_number[phone_number_len]=(u8)key_press;
			if(phone_number_len<PHONE_NUMBER_MAX_LENGTH)
			{
			  phone_number_len++;			
			}			
		  }
		}
		else
		{
		  if(dialPressNumber>0 && dialPressNumber<=4)
		   {//�̰��ǲ���		      		      
			  phone_number[phone_number_len]=0;
			 if(sendAtCmdNo==4)
			 {//���ڲ��ţ�ִ�йҶ�����
			 	//display_dial_pic(0); 
				displayStringWidthScreenPos(6,0,"            ");
				send_at_cmd("ATH\r\n",5);
				sendAtCmdNo=0;
			 }
			 else
			 {//��ʾ������ʾ
				//display_dial_pic(1);
				displayStringWidthScreenPos(6,0,"Dial......");
				send_dial_at(phone_number);
				displayStringWidthScreenPos(6,0,"           ");
				 //phone_number_len=0;
			 }		    	
		   }

		   dialPressNumber=0;
		  
		   if(count_s5>20)//5���ּ�ʱ��
		   {
		       if(networkIsReg!=1)
			   {
				 send_at_cmd("AT+CREG? \r\n",0);
			   }
		       if(cld_is_connect()!=AT_CMD_SUCCESS && networkIsReg==1)
			   {
			      SendString(USART1,"Start AiCloud Connect\r\n" ) ;

				  displayStringWidthScreenPos(4,0,"AiCld start.  ");  
			      send_aicloud_at();				  
			   }

			   count_s5=0;
		   }

		   if(count_s10>40)//10���ּ�ʱ��
		   {		     
			   count_s10=0;
		   } 
		}	
	
		delay_ms(200);
		count_s5++;
		count_s10++;
	}  
}
