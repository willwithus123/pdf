

#ifndef  _AT_PROC_H_
#define  _AT_PROC_H_

#include "config.h"


typedef enum
{    
  AT_CMD_SUCCESS=1,  
  AT_CMD_FAILED=100,
  AT_CMD_TIMEOUE=101,
  AT_CMD_UNKNOWN=255 

}AT_CMD_RESULT;

/////TCP/IP�豸����Э��/////
typedef struct
{
    u8 mode;//'0'-off,'1'-on,'2'-bilnk
	u8 time;//����ʱ�䣬0-9ms
	u8 red;//'1','0'
	u8 green;//'1','0'
	u8 blue;//'1','0'	
}LED_CONFIG;

typedef struct
{
    u8 mode;//'0'--�أ�'1'--��	
	u8 time;
}BEEP_CONFIG;

typedef struct
{
    u8 mode;//'0'--�أ�'1'--��	
	u8 time;	
}RELAY_CONFIG; 

typedef struct
{
   u8 mode;//'r'--reset module
}A6_MODULE_CONFIG;

typedef struct
{
   u8 device;//'1'--led,'2'--beep,'3'--JDQ��'4'--A6 module
   union
   {
     LED_CONFIG led_config;
	 BEEP_CONFIG beep_config;
	 RELAY_CONFIG  relay_config;
	 A6_MODULE_CONFIG module_config;
   }config;

}CTRL_PROTOL;
/////////////////////////////////

extern u8 sendAtCmdNo;

extern  u8 networkIsReg;

void send_at_cmd(u8* cmd,u8 atCmdNo); //����AT		
void send_dial_at(u8 phone_number[]); //���ʹ�绰AT
void send_sms_at(u8 phone_number[]);  //���Ͷ���Ϣ

void send_aicloud_at();  //�������Ӱ��ſ���

void at_proc(u8* pCdmStr,u8 length);//AT����ֵ��������

u8   cld_is_connect();



 u8 mem_cmp(u8 *src,u8 *dst,u8 len);
 u8 str_len(u8* string);
#endif