


#ifndef	__A6_MODULE_H
#define	__A6_MODULE_H

#include	"config.h"


void  a6_module_init();
void  a6_module_on();
void  a6_module_reset();
void  a6_module_off();

#endif

